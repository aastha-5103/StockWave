// Stock Data Analysis Project
// CIS 4930 Project 1
// Name: Aastha Sangani
// U-Number: U73625733

#pragma once

// Including necessary libraries to import functionalities
using namespace System;
using namespace System::Globalization;

// Declaration of candlestick class and properties in the body 
public ref class candlestick
{
public:
	// Properties which we will be storing for candlestick class
	property DateTime Date; // Date property: Represents the date of the candlestick in DateTime format.
	property double Open; // Open property: Represents the opening price of the stock in double format.
	property double High; // High property: Represents the highest price of the stock in double format.
	property double Low; // Low property: Represents the lowest price of the stock in double format.
	property double Close; // Close property: Represents the closing price of the stock in double format.
	property unsigned long long Volume; // Volume property: Represents the volume of stock trading in unsigned long long format.
	
	// Constructor declaration: Initializes a candlestick object using a CSV line.
	candlestick(String^ csvLine);
};
