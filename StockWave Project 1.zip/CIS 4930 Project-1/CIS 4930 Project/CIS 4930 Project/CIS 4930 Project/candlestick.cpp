// Stock Data Analysis Project
// CIS 4930 Project 1
// Name: Aastha Sangani
// U-Number: U73625733


#include "pch.h"
// Including the header file for the candlestick class
#include "candlestick.h"

// Constructor for candlestick class
candlestick::candlestick(String^ csvLine)
{
	// Define the format for the date
	String^ dateFormat = "yyyy-MM-dd";

	// Define the delimiter used for splitting the CSV file. Here, ',' is chosen since the CSV file is comma-separated. 
	array<wchar_t>^ delimiters = { L','};
	// Splitting csv file into individual values
	array<String^>^ values = csvLine->Split(delimiters, StringSplitOptions::RemoveEmptyEntries);
	
	// Check if the CSV file is split into 7 different values 
	if (values->Length == 7)
	{
		// Extract the date from the first value (index 0) using the specified date format
		Date = DateTime::ParseExact(values[0], dateFormat, CultureInfo::InvariantCulture);
		// Extract the open price/value
		Open = Double::Parse(values[1], CultureInfo::InvariantCulture);
		// Extract the high price/value
		High = Double::Parse(values[2], CultureInfo::InvariantCulture);
		// Extract the low price/value
		Low = Double::Parse(values[3], CultureInfo::InvariantCulture);
		// Extract the close price/value
		Close = Double::Parse(values[4], CultureInfo::InvariantCulture);
		// Extract the volume of the stock
		Volume = Int64::Parse(values[6]);
	}
}