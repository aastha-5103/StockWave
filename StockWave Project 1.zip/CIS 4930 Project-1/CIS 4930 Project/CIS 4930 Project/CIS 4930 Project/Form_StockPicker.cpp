// Stock Data Analysis Project
// CIS 4930 Project 1
// Name: Aastha Sangani
// U-Number: U73625733

#include "pch.h"
// Including the header file for Form_StockPicker.h
#include "Form_StockPicker.h"
// Including the header file for candlestick.h
#include "candlestick.h"

namespace CppCLRWinFormsProject {

	/// <summary>
	/// This function retrieves candlestick data from a file. It iterates through each line of the file and compiles a list of all candlesticks.
	/// candlesticks. 
	/// </summary>
	/// <param name="filePath"> The path and name selected by the user.</param>
	/// <returns>A list containing all candlesticks read from the file.</returns>
	List<candlestick^>^ Form_StockPicker::readCandlestickDataFromFile(String^ filePath)
	{
		// Create a list to store list of all candlesticks. 
		List<candlestick^>^ listOfCandlesticks = gcnew List<candlestick^>(1024);

		// Check if the file exists
		if (File::Exists(filePath))
		{
			// Open the file for reading using StreamReader
			StreamReader^ reader = gcnew StreamReader(filePath);
			// Read the first line / header of the csv file
			String^ line = reader->ReadLine(); 
			// Read lines until the end of file
			while ((line = reader->ReadLine()) != nullptr)
			{
				// Create a candlestick object from the line.  
				candlestick^ singlecandlestick = gcnew candlestick(line);
				// Add all the candlesticks information you get into listOfCandlesticks
				listOfCandlesticks->Add(singlecandlestick);
			}
			// Close the reader after iterating through the file.
			reader->Close();
		}
		else
		{
			// If the selected file does not exist, display an error message.
			Console::WriteLine("Error: File does not exist");
		}
		// Return the list of all candlesticks obtained from the CSV file. 
		return listOfCandlesticks;
	}

	/// <summary>
	/// This function filters the list of candlesticks based on the start and end dates selected by the user.
	/// </summary>
	/// <param name="loc"> The list of all candlesticks obtained from readCandlestickDataFromFile.</param>
	/// <returns> A list containing the filtered candlesticks to display in the dataGridView and chart.</returns>
	BindingList<candlestick^>^ Form_StockPicker::filterCandlesticks(List<candlestick^>^ loc)
	{
		// Create a temporary list to store filtered candlesticks
		List<candlestick^>^ tempList = gcnew List<candlestick^>(loc->Count);
		// Iterate through each candlestick in the input list
		for each (candlestick ^ candlestick in listOfCandlesticks)
		{
			// If the candlestick's date is greater than end date, stop filtering
			if (candlestick->Date > dateTimePicker_endDate->Value)
			{
				break;
			}
			// If the candlestick's date falls within the specified date range, then add it to tempList.
			if (candlestick->Date >= dateTimePicker_startDate->Value && candlestick->Date <= dateTimePicker_endDate->Value)
			{
				tempList->Add(candlestick);
			}
		}

		// Create a binding list from the temporary list and return it
		BindingList<candlestick^>^ boundListOfCandlesticks = gcnew BindingList<candlestick^>(tempList);
		// Return the binding list of all filtered candlesticks
		return boundListOfCandlesticks;
	}
}