﻿// Stock Data Analysis Project
// CIS 4930 Project 1
// Name: Aastha Sangani
// U-Number: U73625733

#pragma once

#include "candlestick.h"

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Collections::Generic;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Summary: Represents the Form_StockPicker class.
	/// </summary>
	public ref class Form_StockPicker : public System::Windows::Forms::Form
	{
	// Declaring a private property to hold the list of Candlesticks
	private: List<candlestick^>^ listOfCandlesticks;
    // Declaring a private property to hold binding list of Candlesticks
	private: BindingList<candlestick^>^ boundListOfCandlesticks;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_startDate;
	 // Declaring private controls for user interface elements.
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart_OHLCV;
	private: System::Windows::Forms::Button^ button_Update;
	private: System::Windows::Forms::Label^ label_startDate;
	private: System::Windows::Forms::Label^ label_endDate;

	private: System::Windows::Forms::Label^ label1;

	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_endDate;


	public:
		Form_StockPicker(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Cleans up all the resources that are being used.
		/// </summary>
		~Form_StockPicker()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button_LoadStock;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog_LoadStock;
	private: System::Windows::Forms::DataGridView^ dataGridView_candlesticks;
	protected:

	protected:




	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea2 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^ legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::Series^ series2 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->button_LoadStock = (gcnew System::Windows::Forms::Button());
			this->openFileDialog_LoadStock = (gcnew System::Windows::Forms::OpenFileDialog());
			this->dataGridView_candlesticks = (gcnew System::Windows::Forms::DataGridView());
			this->dateTimePicker_startDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->dateTimePicker_endDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->chart_OHLCV = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->button_Update = (gcnew System::Windows::Forms::Button());
			this->label_startDate = (gcnew System::Windows::Forms::Label());
			this->label_endDate = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView_candlesticks))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart_OHLCV))->BeginInit();
			this->SuspendLayout();
			// 
			// button_LoadStock
			// 
			this->button_LoadStock->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10));
			this->button_LoadStock->Location = System::Drawing::Point(958, 223);
			this->button_LoadStock->Name = L"button_LoadStock";
			this->button_LoadStock->Size = System::Drawing::Size(136, 79);
			this->button_LoadStock->TabIndex = 0;
			this->button_LoadStock->Text = L"Load Stock";
			this->button_LoadStock->UseVisualStyleBackColor = true;
			this->button_LoadStock->Click += gcnew System::EventHandler(this, &Form_StockPicker::button_LoadStock_Click);
			// 
			// openFileDialog_LoadStock
			// 
			this->openFileDialog_LoadStock->FileName = L"openFileDialog_LoadStock";
			this->openFileDialog_LoadStock->Filter = L"All Files|*.csv|Monthly|*-Month.csv|Weekly|*-Week.csv|Daily|*-Day.csv";
			this->openFileDialog_LoadStock->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form_StockPicker::openFileDialog_LoadStock_FileOk);
			// 
			// dataGridView_candlesticks
			// 
			this->dataGridView_candlesticks->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView_candlesticks->Location = System::Drawing::Point(37, 21);
			this->dataGridView_candlesticks->Name = L"dataGridView_candlesticks";
			this->dataGridView_candlesticks->RowHeadersWidth = 51;
			this->dataGridView_candlesticks->RowTemplate->Height = 24;
			this->dataGridView_candlesticks->Size = System::Drawing::Size(907, 286);
			this->dataGridView_candlesticks->TabIndex = 6;
			// 
			// dateTimePicker_startDate
			// 
			this->dateTimePicker_startDate->Location = System::Drawing::Point(962, 117);
			this->dateTimePicker_startDate->Name = L"dateTimePicker_startDate";
			this->dateTimePicker_startDate->Size = System::Drawing::Size(265, 22);
			this->dateTimePicker_startDate->TabIndex = 2;
			this->dateTimePicker_startDate->Value = System::DateTime(2021, 1, 1, 0, 0, 0, 0);
			// 
			// dateTimePicker_endDate
			// 
			this->dateTimePicker_endDate->Location = System::Drawing::Point(962, 177);
			this->dateTimePicker_endDate->Name = L"dateTimePicker_endDate";
			this->dateTimePicker_endDate->Size = System::Drawing::Size(265, 22);
			this->dateTimePicker_endDate->TabIndex = 3;
			// 
			// chart_OHLCV
			// 
			chartArea1->AlignWithChartArea = L"ChartArea_Volume";
			chartArea1->AxisY->IsStartedFromZero = false;
			chartArea1->Name = L"ChartArea_OHLC";
			chartArea2->Name = L"ChartArea_Volume";
			this->chart_OHLCV->ChartAreas->Add(chartArea1);
			this->chart_OHLCV->ChartAreas->Add(chartArea2);
			legend1->Name = L"Legend1";
			this->chart_OHLCV->Legends->Add(legend1);
			this->chart_OHLCV->Location = System::Drawing::Point(37, 325);
			this->chart_OHLCV->Name = L"chart_OHLCV";
			series1->ChartArea = L"ChartArea_OHLC";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Candlestick;
			series1->CustomProperties = L"PriceDownColor=Red, PriceUpColor=Green";
			series1->Legend = L"Legend1";
			series1->Name = L"OHLC";
			series1->XValueMember = L"Date";
			series1->XValueType = System::Windows::Forms::DataVisualization::Charting::ChartValueType::Date;
			series1->YValueMembers = L"High, Low, Open, Close";
			series1->YValuesPerPoint = 4;
			series2->ChartArea = L"ChartArea_Volume";
			series2->Legend = L"Legend1";
			series2->Name = L"Volume";
			series2->XValueMember = L"Date";
			series2->XValueType = System::Windows::Forms::DataVisualization::Charting::ChartValueType::DateTime;
			series2->YValueMembers = L"Volume";
			series2->YValueType = System::Windows::Forms::DataVisualization::Charting::ChartValueType::Int64;
			this->chart_OHLCV->Series->Add(series1);
			this->chart_OHLCV->Series->Add(series2);
			this->chart_OHLCV->Size = System::Drawing::Size(1179, 443);
			this->chart_OHLCV->TabIndex = 7;
			this->chart_OHLCV->Text = L"chart1";
			// 
			// button_Update
			// 
			this->button_Update->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10));
			this->button_Update->Location = System::Drawing::Point(1100, 223);
			this->button_Update->Name = L"button_Update";
			this->button_Update->Size = System::Drawing::Size(124, 79);
			this->button_Update->TabIndex = 5;
			this->button_Update->Text = L"Update";
			this->button_Update->UseVisualStyleBackColor = true;
			this->button_Update->Click += gcnew System::EventHandler(this, &Form_StockPicker::button_Update_Click);
			// 
			// label_startDate
			// 
			this->label_startDate->AutoSize = true;
			this->label_startDate->Location = System::Drawing::Point(966, 93);
			this->label_startDate->Name = L"label_startDate";
			this->label_startDate->Size = System::Drawing::Size(66, 16);
			this->label_startDate->TabIndex = 6;
			this->label_startDate->Text = L"Start Date";
			// 
			// label_endDate
			// 
			this->label_endDate->AutoSize = true;
			this->label_endDate->Location = System::Drawing::Point(965, 155);
			this->label_endDate->Name = L"label_endDate";
			this->label_endDate->Size = System::Drawing::Size(63, 16);
			this->label_endDate->TabIndex = 7;
			this->label_endDate->Text = L"End Date";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 17, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(963, 32);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(275, 33);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Stock Data Analysis";
			this->label1->Click += gcnew System::EventHandler(this, &Form_StockPicker::label1_Click);
			// 
			// Form_StockPicker
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1315, 788);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label_endDate);
			this->Controls->Add(this->label_startDate);
			this->Controls->Add(this->button_Update);
			this->Controls->Add(this->chart_OHLCV);
			this->Controls->Add(this->dateTimePicker_endDate);
			this->Controls->Add(this->dateTimePicker_startDate);
			this->Controls->Add(this->dataGridView_candlesticks);
			this->Controls->Add(this->button_LoadStock);
			this->Name = L"Form_StockPicker";
			this->Text = L"Form_StockPicker";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView_candlesticks))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart_OHLCV))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	// Declaration of the readCandlestickDataFromFile function, which is defined in a separate .cpp file.
	private: List<candlestick^>^ readCandlestickDataFromFile(String^ filePath);
	// Declaration of the filterCandlesticks function, which is defined in a separate .cpp file.
	private: BindingList<candlestick^>^ filterCandlesticks(List<candlestick^>^ loc);

	/// <summary>
	/// Handles the click event for the load data button
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	/// <returns></returns>
	private: System::Void button_LoadStock_Click(System::Object^ sender, System::EventArgs^ e) {
		// Opens the file dialog box to allow the user to select a file.
		openFileDialog_LoadStock->ShowDialog();
	}
	/// <summary>
	/// Reads candlestick data when a file is selected.
	/// </summary>
	private: void readCandlesticksData(){
		// Retrieves a list of all candlesticks by calling the readCandlestickDataFromFile function and passing the selected filename.
		listOfCandlesticks = readCandlestickDataFromFile(openFileDialog_LoadStock->FileName);
	}
	/// <summary>
	/// Filters candlesticks based on the user-selected range.
	/// </summary>
	private: void FilterCandlestickData() {
		// Filters the candlesticks and stores the result in a binding list using the filterCandlesticks function.
		boundListOfCandlesticks = filterCandlesticks(listOfCandlesticks);
	}

	/// <summary>
	/// Adjusts the Y-axis of the candlestick chart to improve visibility.
	/// </summary>
	/// <param name="listOfCandlesticks">List of candlestick objects.</param>
	void Form_StockPicker::NormalizeChart(List<candlestick^>^ listOfCandlesticks)
	{
		if (listOfCandlesticks == nullptr || listOfCandlesticks->Count == 0)
			return; // Exit if list is empty

		// Initialize min and max values with the first candlestick values
		double min = listOfCandlesticks[0]->Low;
		double max = listOfCandlesticks[0]->High;

		// Find actual min and max from the list
		for each (candlestick ^ c in listOfCandlesticks)
		{
			if (c->Low < min) min = c->Low;
			if (c->High > max) max = c->High;
		}

		// Add 5% padding for better visualization
		double padding = (max - min) * 0.02;
		double minY = min - padding;
		double maxY = max + padding;

		// Set Y-axis limits
		chart_OHLCV->ChartAreas["ChartArea_OHLC"]->AxisY->Minimum = minY;
		chart_OHLCV->ChartAreas["ChartArea_OHLC"]->AxisY->Maximum = maxY;
	}

	/// <summary>
	/// Displays candlestick data in DataGridView and Chart.
	/// </summary>
	void Form_StockPicker::DisplayCandlestickData() {
		// Binds the filtered candlestick list to the DataGridView.
		dataGridView_candlesticks->DataSource = boundListOfCandlesticks;
		// Binds the candlestick list as the data source for the chart.
		chart_OHLCV->DataSource = boundListOfCandlesticks;
		// Binds the data to the chart.
		chart_OHLCV->DataBind();
		// Normalize the chart Y-axis based on the displayed data
		List<candlestick^>^ candlestickList = gcnew List<candlestick^>(boundListOfCandlesticks);
		NormalizeChart(candlestickList);

	}

	/// <summary>
	/// Handles the file selection event of the open file dialog box.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	/// <returns></returns>
	private: System::Void openFileDialog_LoadStock_FileOk(System::Object^ sender, System::ComponentModel::CancelEventArgs^ e) {
		// Reads data from the selected file.
		readCandlesticksData();
		// Filters the candlesticks based on the date range.
		FilterCandlestickData();
		// Binds the filtered data to DataGridView and Chart
		dataGridView_candlesticks->DataSource = boundListOfCandlesticks;
		chart_OHLCV->DataSource = boundListOfCandlesticks;
		chart_OHLCV->DataBind();
		
		List<candlestick^>^ candlestickList = gcnew List<candlestick^>(boundListOfCandlesticks);
		NormalizeChart(candlestickList);
		// Displays the candlestick chart and DataGridView.
		// DisplayCandlestickData();
	}
	/// <summary>
	/// Handles the click event of the update button.
	/// </summary>
	/// <param name="sender"></param>
	/// <param name="e"></param>
	/// <returns></returns>
	private: System::Void button_Update_Click(System::Object^ sender, System::EventArgs^ e) {
		// Filters the candlesticks based on the date range.
		FilterCandlestickData();
		// Updates the DataGridView and Chart
		dataGridView_candlesticks->DataSource = boundListOfCandlesticks;
		chart_OHLCV->DataSource = boundListOfCandlesticks;
		chart_OHLCV->DataBind();

		// 🔹 Normalize the chart after updating data
		List<candlestick^>^ candlestickList = gcnew List<candlestick^>(boundListOfCandlesticks);
		NormalizeChart(candlestickList);
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
};